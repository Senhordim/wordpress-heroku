<?php

add_filter( 'rwmb_meta_boxes', 'swm_register_custom_posttypes_metaboxes' );

/**
 * Register meta boxes
 *
 * @return void
 */
function swm_register_custom_posttypes_metaboxes( $meta_boxes )
{
	
	$prefix = 'swm_';

	
	// Portfolio Options

	$meta_boxes[] = array(		
		'id' => 'swm-portfolio-metabox',	
		'title' => __('Portfolio Options', 'swmtranslate'),				
		'pages' => array( 'portfolio' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array(
				"name" => __('Project Type', 'swmtranslate'),				
				"id" => "{$prefix}portfolio_project_type",
				"std" => "default",
				"type" => "select",				
				"options" => array(		
					"image" => __('Image', 'swmtranslate'),
					"video" => __('Video', 'swmtranslate')							
				),				
			),					
			array( 
				'name' => __('Add YouTube/Vimeo Video URL', 'swmtranslate'),				
				'id' => "{$prefix}portfolio_video",
				'std' => '',			
				"type" => "text"
			)			
		)
	);

	// Testimonials Options
	
	$meta_boxes[] = array(		
		'id' => 'swm-testimonials-metabox',	
		'title' => __('Testimonials Options', 'swmtranslate'),				
		'pages' => array( 'testimonials' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array( 
				'name' => __('Client Details (optional)', 'swmtranslate'),	
				'desc' => __('Client designation, city or country name etc. ', 'swmtranslate'),			
				'id' => "{$prefix}client_details",
				'std' => '',			
				"type" => "text"
			),					
			array( 
				'name' => __('Website URL (optional)', 'swmtranslate'),	
				'desc' => __('Client website FULL PATH URL. <br />Example: http://www.loremips.com', 'swmtranslate'),
				'id' => "{$prefix}website_url",
				'std' => '',			
				"type" => "text"
			)				
		)
	);

	// Logos Options

	$meta_boxes[] = array(		
		'id' => 'swm-logos-metabox',	
		'title' => __('Logo Options', 'swmtranslate'),				
		'pages' => array( 'logos' ),		
		'context' => 'normal',		
		'priority' => 'high',
		'autosave' => true,		
		'fields' => array(	
			array( 
				'name' => __('Client Website URL (optional)', 'swmtranslate'),	
				'desc' => __('Enter client website URl or leave it blank', 'swmtranslate'),			
				'id' => "{$prefix}client_logo_url",
				'std' => '',			
				"type" => "text"
			)					
		)
	);

	return $meta_boxes;
}