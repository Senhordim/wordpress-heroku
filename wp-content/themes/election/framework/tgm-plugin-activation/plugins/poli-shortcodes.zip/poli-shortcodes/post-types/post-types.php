<?php
require_once( plugin_dir_path( __FILE__ ) .'portfolio.php' );
require_once( plugin_dir_path( __FILE__ ) .'testimonial.php' );