<?php

/* ************************************************************************************** 
	Testimonials Post Type
************************************************************************************** */

add_action( 'init', 'swm_posttype_testimonials' );
if (!function_exists('swm_posttype_testimonials')) {
	function swm_posttype_testimonials() {	
		$labels = array(
			'name' => __( 'Testimonials', 'swmtranslate'),
			'singular_name' => __( 'Testimonial' , 'swmtranslate'),
			'add_new' =>  __( 'Add New' , 'swmtranslate'),
			'add_new_item' => __('Add New testimonial', 'swmtranslate'),
			'edit_item' => __('Edit Testimonial', 'swmtranslate'),
			'new_item' => __('New Testimonial Item', 'swmtranslate'),
			'view_item' => __('View Testimonial Item', 'swmtranslate'),
			'search_items' => __('Search Testimonials', 'swmtranslate'),
			'not_found' =>  __('No testimonial items found', 'swmtranslate'),
			'not_found_in_trash' => __('No testimonial items found in Trash', 'swmtranslate'),
			'parent_item_colon' => ''
		);
		  
		$args = array(
			'labels' => $labels,
			'public' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'rewrite' => array('slug' => 'clients-testimonials'),
			'show_ui' => true, 
			'query_var' => true,
			'capability_type' => 'post',
			'hierarchical' => false,		
			'menu_position' => null,
			'supports' => array('title','editor','thumbnail','excerpt')
		); 
		  
		register_post_type(__( 'testimonials' , 'swmtranslate'),$args);	
		
	}
}
/* ------------------------------------------------------------------------------ */	

add_action( 'init', 'swm_posttype_testimonial_taxonomies', 0 );
if (!function_exists('swm_posttype_testimonial_taxonomies')) {
	function swm_posttype_testimonial_taxonomies(){
		
		register_taxonomy(__( "testimonials-categories" , 'swmtranslate'), 
			array(__( "testimonials" , 'swmtranslate'),), 
			array(
				"hierarchical" => true, 
				"query_var" => true, 
				"label" => __( "Categories" , 'swmtranslate'),
				"singular_label" => __( "Testimonials Categories" , 'swmtranslate'),
				"rewrite" => array(
					'slug' => 'testimonials-categories', 
					'hierarchical' => true, 
					'with_front' => false )
			)); 
		
	}
}
/* ------------------------------------------------------------------------------ */
 
add_filter("manage_edit-testimonials_columns", "swm_posttype_testimonials_edit_columns"); 
if (!function_exists('swm_posttype_testimonials_edit_columns')) {
	function swm_posttype_testimonials_edit_columns($columns){  
		$columns = array(  
			"cb" => "<input type=\"checkbox\" />",  
			"title" => __( 'Client Name' , 'swmtranslate'),
			"Image" => __( 'Image' , 'swmtranslate'),
			"client-details" => __( 'Client Details' , 'swmtranslate'),	
			"Category" => __( 'Category' , 'swmtranslate'),					
			"website-url" => __( 'Website URL' , 'swmtranslate')
		); 
		return $columns;  
	} 
}	
/* ------------------------------------------------------------------------------ */
	
add_action("manage_posts_custom_column",  "swm_posttype_testimonials_image_column");	
if (!function_exists('swm_posttype_testimonials_image_column')) {
	function swm_posttype_testimonials_image_column($column){  
		global $post;  
		switch ($column)  {
			
			case "title":  
				echo get_the_title();  
				break;
				
			case "client-details":
				if(get_post_meta($post->ID, "swm_client_details", true)){
					echo get_post_meta($post->ID, "swm_client_details", true);
				} else {echo '---';}
				break;
				
			case "website-name":
				if(get_post_meta($post->ID, "swm_website_title", true)){
					echo get_post_meta($post->ID, "swm_website_title", true);
				} else {echo '---';}
				break;

			case 'Category':  
				echo wp_strip_all_tags( get_the_term_list($post->ID, 'testimonials-categories', '', ', ',''));  
				break;	
				
			case "website-url":
				if(get_post_meta($post->ID, "swm_website_url", true)){
					echo get_post_meta($post->ID, "swm_website_url", true);
				} else {echo '---';}
				break;
				
		}  
	}
}
/* Edit "Featured Image" box text --------------------------------------------------- */

add_filter( 'gettext', 'testimonials_post_edit_change_text', 20, 3 );
if (!function_exists('testimonials_post_edit_change_text')) {
	function testimonials_post_edit_change_text( $translated_text, $text, $domain ) {
	    if( ( is_testimonials_admin_page() ) ) {
	        switch( $translated_text ) {
	        case 'Featured Image' :
	            $translated_text = __( 'Add Client Image', 'circle-carousel' );
	        break;
	        case 'Set Featured Image' :
	            $translated_text = __( 'Set client image', 'circle-carousel' );
	        break;
	        case 'Set featured image' :
	            $translated_text = __( 'Set client image', 'circle-carousel' );
	        break;
	        case 'Remove featured image' :
	            $translated_text = __( 'Remove client image', 'circle-carousel' );
	        break;
	        }
	    }
	    return $translated_text;
	}
}

if (!function_exists('is_testimonials_admin_page')) {
	function is_testimonials_admin_page() {
	    global $pagenow;

	    if( $pagenow == 'post-new.php' ) {
	        if( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'testimonials' )
	            return true;
	    }

	    if( $pagenow == 'post.php' ) {
	        if( isset( $_GET['post'] ) && get_post_type( $_GET['post'] ) == 'testimonials' )
	            return true;
	    }
	    return false;
	}
}
if( defined( 'DOING_AJAX' ) && 'DOING_AJAX' ) {
    if( isset( $_POST['post_id'] ) && get_post_type( $_POST['post_id'] ) == 'testimonials' )
        return true;
}